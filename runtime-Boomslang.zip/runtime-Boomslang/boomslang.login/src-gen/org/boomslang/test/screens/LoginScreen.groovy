package org.boomslang.test.screens

class LoginScreen extends org.boomslang.pages.BoomslangScreen {

	static url = "#/login"

	static at = { waitFor { title == "Value" } }

	static content = {
		password (required: true) { module com.myappl.PasswordModule, $("id_password") }
		userName (required: true) { module org.boomslang.module.BoomslangModule, $("id_username") }
		submit (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("id_submit") }
		loginWindow (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrectId") }
		userNameLabel (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrectId") }
	}

}
