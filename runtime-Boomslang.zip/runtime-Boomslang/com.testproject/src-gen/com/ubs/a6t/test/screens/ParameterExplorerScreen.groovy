package com.ubs.a6t.test.screens

class ParameterExplorerScreen extends org.boomslang.pages.BoomslangScreen {

	static url = ""

	static at = { waitFor { title == "Parameter Explorer" } }

	static content = {
		parameterExplorerTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("ParameterExplorerPM") }
		clearFilter (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrextId") }
	}

}
