package com.ubs.a6t.test.screens

class SuitabilitySetExplorerScreen extends org.boomslang.pages.BoomslangScreen {

	static url = ""

	static at = { waitFor { title == "Suitability Set Explorer" } }

	static content = {
		suitabilitySetExplorerTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("SuitabilitySetExplorerPM") }
		clearFilter (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrextId") }
	}

}
