package com.ubs.a6t.test.screens

class ServiceFeatureExplorerScreen extends org.boomslang.pages.BoomslangScreen {

	static url = ""

	static at = { waitFor { title == "Service Feature Explorer" } }

	static content = {
		serviceFeatureExplorerTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("ServiceFeatureExplorerPM") }
	}

}
