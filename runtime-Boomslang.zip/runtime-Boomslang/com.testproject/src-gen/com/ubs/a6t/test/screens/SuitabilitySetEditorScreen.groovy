package com.ubs.a6t.test.screens

class SuitabilitySetEditorScreen extends org.boomslang.pages.BoomslangScreen {

	static url = "suitabilitySetTab"

	static at = { waitFor { title == "Suitability Set Editor" } }

	static content = {
		addItemButton (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("{0}Button_select") }
		removeItemButton (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("{0}Button_deselect") }
		availableItemsFilterInputField (required: true) { module org.boomslang.module.BoomslangModule, $("{0}Text") }
		availableItemsTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("{0}Table_available") }
		selectedItemsTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("{0}Table_selected") }
		ruleNameTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("SuitabilitySetTablePM") }
		addRuleButton (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("AddButton") }
	}

}
