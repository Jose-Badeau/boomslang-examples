package com.ubs.a6t.test.screens

class OfferingExplorerScreen extends org.boomslang.pages.BoomslangScreen {

	static url = ""

	static at = { waitFor { title == "Offering Explorer" } }

	static content = {
		offeringExplorerTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("OfferingExplorerPM") }
		clearFilter (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrextId") }
	}

}
