package com.ubs.a6t.test.screens

class SuitabilityFeatureExplorerScreen extends org.boomslang.pages.BoomslangScreen {

	static url = ""

	static at = { waitFor { title == "Suitability Feature Explorer" } }

	static content = {
		suitabilityFeatureExplorerTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("SuitabilityFeatureExplorerPM") }
		clearFilter (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrextId") }
	}

}
