package com.ubs.a6t.test.screens

class ProductExplorerScreen extends org.boomslang.pages.BoomslangScreen {

	static url = ""

	static at = { waitFor { title == "Product Explorer" } }

	static content = {
		productExplorerTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("ProductExplorerPM") }
		clearFilter (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrextId") }
	}

}
