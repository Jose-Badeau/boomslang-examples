package com.ubs.a6t.test.screens

class TGIdtoSOPIdMappingExplorerScreen extends org.boomslang.pages.BoomslangScreen {

	static url = ""

	static at = { waitFor { title == "TG Id to SOPId Mapping Explorer" } }

	static content = {
		tGIdtoSOPIdMappingExplorerTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("OfferingMappingExplorerPM") }
		clearFilter (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrextId") }
	}

}
