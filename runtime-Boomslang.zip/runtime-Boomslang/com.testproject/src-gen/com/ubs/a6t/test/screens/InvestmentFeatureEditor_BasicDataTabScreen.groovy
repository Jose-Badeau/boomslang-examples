package com.ubs.a6t.test.screens

class InvestmentFeatureEditor_BasicDataTabScreen extends org.boomslang.pages.BoomslangScreen {

	static url = "Basic Data"

	static at = { waitFor { title == "Investment Feature Editor Basic Data Tab" } }

	static content = {
		featureCode (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("FeatureCode") }
		featureLong (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrectId") }
		featureShort (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrectId") }
	}

}
