package com.ubs.a6t.test.screens

class BuildingBlockExplorerScreen extends org.boomslang.pages.BoomslangScreen {

	static url = ""

	static at = { waitFor { title == "Building Block Explorer" } }

	static content = {
		buildingBlockExplorerTable (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("BuildingBlockExplorerPM") }
		clearFilter (required: true , wait:true) { module org.boomslang.module.BoomslangModule, $("replaceWithTheCorrextId") }
	}

}
